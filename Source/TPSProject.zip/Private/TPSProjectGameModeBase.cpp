// Copyright Epic Games, Inc. All Rights Reserved.


#include "TPSProjectGameModeBase.h"
#include  "TPSProject.h"

ATPSProjectGameModeBase::ATPSProjectGameModeBase()
{
	PRINT_LOG(TEXT("My Log : %s"), TEXT("TPS project!"));


}
